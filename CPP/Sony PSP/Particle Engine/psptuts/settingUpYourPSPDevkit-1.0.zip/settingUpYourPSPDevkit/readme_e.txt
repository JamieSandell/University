[SCE CONFIDENTIAL DOCUMENT]
                   Copyright (C) 2006 Sony Computer Entertainment Europe
                                                     All Rights Reserved

"Setting up your PSP(TM) Devkit" video 

<Description>

	This video provides a step-by-step guide to setting up a PSP DTP-1000 
	development unit.

	It also demonstrates how to:
	- Update the kernel of your development unit to the latest kernel version
	- Initialise your development unit to factory default settings.


<History>
	v1.0.0: First version
