using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SystemManagement;

namespace WindowsApplication1
{
    public partial class StaffMenu : Form
    {
        public StaffMenu(IEmployee employee)
        {
            InitializeComponent();
        }
    }
}